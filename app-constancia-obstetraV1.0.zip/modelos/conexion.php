<?php

class Conexion
{

	static public function conectar()
	{

		/* CONEXION CON EL HOSTING DIRIS LIMA SUR - MYSQL */

/* 		$link = new PDO(
			"mysql:host=localhost;dbname=colegi30_dbobstetras",
			"colegi30_colegi30",
			"20151597531994Vlad"
		);
		$link->exec("set names utf8");  */


/* CONEXION CON LA BASE DE DATOS LOCAL - MYSQL */

		$link = new PDO(
			"mysql:host=localhost;dbname=colegi30_dbobstetras",
			"root",
			"");
		$link->exec("set names utf8");

/* CONEXION CON LA BASE DE DATOS LOCAL - SQL SERVER*/

/* 		$link = new PDO('sqlsrv:Server=ETF_DESARROLLO;Database=dirislim_visita', 'sa', '1597531994');
		$link->exec("set names utf8"); */

		/* CONEXION CON LA BASE DE DATOS CASA - SQL SERVER*/

/* 		$link = new PDO('sqlsrv:Server=DESKTOP-PNO0NV8\SQLEXPRESS,1433;Database=dirislim_visita', 'sa', '1597531994Vlad');
		$link->exec("set names utf8");
 */
		 return $link; 
	}
}
