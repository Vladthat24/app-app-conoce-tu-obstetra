<footer class="main-footer">
	<strong>Copyright &copy; 2020 <a href="http://colegiodeobstetras.pe/" target="_blank" style="color: #bc3c3c;">Colegio de Obstetras</a>.</strong>
	Todos los derechos reservados YCM.
</footer>